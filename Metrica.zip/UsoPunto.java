/**
Proyecto Puntos2D
Clase UsoPunto, es la clase que contiene al main, a partir de esta clase se ejecuta el programa, en el método main crea al objeto Vista que nos da nuestro entorno gráfico
1/10/22
@author CruzPinedaFernando
 **/
package Metrica;

public class UsoPunto {

    public static void main(String[] args){
	Vista vistita= new Vista();
        vistita.setVisible(true);
    }
}
